import java.util.Scanner;

public class Main{
Animal [] farm;
   int count;
 public Main(int size){
  farm = new Animal[size];
  count = 0;
 }
 
 public Main(){
  this(50);
 }
 
 public String toString(){
  StringBuffer sb = new StringBuffer();
  for(int i = 0; i < count; i++)
   sb.append(farm[i] +"\n");
  return sb.toString();
 }
 
 public void add(Animal a){
  farm[count++] = a;
 }

   public static void main(String[] args){
   
   
      Scanner scan = new Scanner(System.in);
      String name;
      int age;
      String breed;
      System.out.print("Enter name >> ");
      name = scan.nextLine();
      
      System.out.print("Enter age >> ");
      age = scan.nextInt();
      
      System.out.print("Enter breed >> ");
      breed = scan.next();
      
      if(breed.equals("dog")){
         Dog object = new Dog(name, age, breed);
      
         System.out.print(""+object.toString());
      
         System.out.print(object.sound());
      }
      else if(breed.equals("cat")){
         Cat object = new Cat(name, age, breed);
      
         System.out.print(""+object.toString());
      
         System.out.print(object.sound());

      }
   }
}